package com.thewawpro.zcontent.util;

import net.minecraft.item.Item;

import java.util.ArrayList;

public class GlobalVars {

    public static final ArrayList<Item> itemList = new ArrayList<>();
    public static int size = 0;
}
